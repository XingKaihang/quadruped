package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.valuefunction;

import java.util.Map.Entry;


import org.apache.log4j.Logger;
import org.encog.engine.network.activation.ActivationSigmoid;
import org.encog.engine.network.activation.ActivationTANH;
import org.encog.mathutil.BoundNumbers;
import org.encog.ml.data.MLData;
import org.encog.ml.data.MLDataSet;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.ml.data.basic.BasicMLDataSet;
import org.encog.neural.networks.BasicNetwork;
import org.encog.neural.networks.layers.BasicLayer;
import org.encog.neural.networks.training.propagation.TrainingContinuation;
import org.encog.neural.networks.training.propagation.back.Backpropagation;
import org.encog.neural.networks.training.propagation.resilient.RPROPType;
import org.encog.neural.networks.training.propagation.resilient.ResilientPropagation;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NetworkFeatures;
import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.StateActionPair;


import cern.jet.random.Uniform;


/**
 * Implements an NFQFunction for the Encog-Library
 * @author tokicm
 *
 */
public class EncogQFunctionBackpropMLP extends NFQFunction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4740691732686298668L;
	private BasicNetwork network;	
	private TrainingContinuation trainContinuation = null;
    
	// Logger
    private final static Logger log4j = Logger.getLogger("EncogQFunctionBackpropMLP");
    
    public final static double minWeight = -0.5;
	public final static double maxWeight = 0.5;
	
	// learning rate for gradient
	public double eta = 0.01;
	// learning rate for momentum term
	public double alpha = 0.01;
	
	private int threads = 1;
	
	//private int layers[];
	

	public EncogQFunctionBackpropMLP(ActionSet actionSet, NetworkFeatures features, int[] layers)
	{
		super (actionSet, features);
		this.network = createNetwork(layers);
        //this.layers = layers;
	}
	
	/**
	 * sets the learning rate 
	 * @param eta
	 */
	public void setLearningRate(double eta) {
		this.eta = eta;
	}
	
	/**
	 * sets the learning rate for the momentum term
	 * @param alpha
	 */
	public void setMomentum (double alpha) {
		this.alpha = alpha;
	}
	
	public static BasicNetwork createNetwork(int[] layers) {
		
		 // create neural network
        BasicNetwork network = new BasicNetwork();

        String data = "";
        for (int i=0; i< layers.length; i++) {
        	
        	// input layer: no activation function, 1 bias neuron
        	if (i==0) {
        		network.addLayer(new BasicLayer(null, true, layers[i]));        		
        	
        	// output layer: TANH activation, no bias neuron
        	} else if (i == (layers.length-1)) {
        		//network.addLayer(new BasicLayer(null, false, layers[i]));
        		network.addLayer(new BasicLayer(new ActivationTANH(), false, layers[i]));
        		//System.out.println ("adding layer with sigmoid activation and " + layers[i]  + " neurons");
        		
        	// hidden layers: TANH activation, 1 bias neuron
            } else {
        		network.addLayer(new BasicLayer(new ActivationTANH(), true, layers[i]));        		
        		//System.out.println ("adding layer with activation and " + layers[i]  + " neurons");
        	}
        	
        	
    		data += (layers[i] + ", ");
        }
        log4j.debug("Generating network with layers: " + data);
        network.getStructure().finalizeStructure();
		network.reset();
		
		
		// INITIALIZE WEIGHTS
		//System.out.println ("Layer 0=>1");
		for (int k=0; k<network.getLayerCount()-1; k++) {
			//System.out.println ("Layer " + (k+1) + "=>" + (k+2));
			for (int i=0; i<network.getLayerNeuronCount(k); i++) {
				for (int j=0; j<network.getLayerNeuronCount(k+1); j++) {
					network.setWeight(k, i, j, Uniform.staticNextDoubleFromTo(minWeight, maxWeight));
					//System.out.println ("i=" + i + ", j=" + j + ", w=" + network.getWeight(k, i, j));
				}
			}
		}
		
		//System.exit(-1);
		return network;
	}

	
	
	@Override
	public double getValue(State state, Action action)
	{
		MLData output = this.network.compute(new BasicMLData(features.getInputFeatures(state, action)));
		double netQ = BoundNumbers.bound(output.getData(0));
		return features.denormalizeOutput(netQ);
	}
	

	/**
	 * start neural network training
	*/
	public void trainBatch(int epochs) {

		
		double[][] input = new double[qTable.size()][features.getNumInputFeatures()];
		double[][] output = new double[qTable.size()][1];
					
		// normalize input and output for training
		int i=0;
		for (Entry<StateActionPair, Double> e : qTable.entrySet() ) {			

			input[i] = features.getInputFeatures(e.getKey().getState(), e.getKey().getAction());			
			output[i] = new double[]{features.normalizeOutput(e.getValue())};
			i++;
		}

		// create new networks
		//network = createNetwork(layers);
		
		// create new trainingdata set
		MLDataSet trainingSet = new BasicMLDataSet(input, output);
		
		// train the neural network
		Backpropagation netLearner = new Backpropagation(network, trainingSet);
		netLearner.setLearningRate(eta);
		netLearner.setMomentum(alpha);
		netLearner.setThreadCount(threads);
		
		if (trainContinuation != null) {
			netLearner.resume(trainContinuation);
			netLearner.setTraining(trainingSet);
		}
		
		
		// TRAINING
		int trainIteration=0;
		log4j.debug("Training " + trainingSet.size() + " data patterns");
		do {
			//System.out.println ("ERROR: " + this.netLearner.getError());
			netLearner.iteration();
			trainIteration++;
		//} while (this.netLearner.getError() > 0.000004 && trainIteration < TRAIN_EPISODES);
			//System.out.print ("\rERROR: " + this.netLearner.getError() +  ", ITERATIONS=" + trainIteration);
		//} while (trainIteration < TRAIN_EPISODES);
		} while (trainIteration < epochs);
		//System.out.println();
		//this.netLearner.finishTraining();
		log4j.debug ("ERROR: " + netLearner.getError() + ", ITERATIONS=" + trainIteration + "\n");
		netLearner.finishTraining();
		
		
		//EncogUtility.trainConsole(network, trainingSet, 10 ); // 10 minutes

		//this.netLearner.finishTraining();
		//this.trainContinuation = netLearner.pause();
	}
	
	/**
	 * set the amount of learning threads for multi-core machines (default: 1)
	 * @param threads
	 */
	public void setThreadCount (int threads) {
		this.threads = threads; 
	}
}
