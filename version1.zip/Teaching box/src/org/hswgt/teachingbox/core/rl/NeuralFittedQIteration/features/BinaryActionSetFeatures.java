package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.DimensionFeatures;
import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Action;

/**
 * This class associates each Action from the ActionSet to a single neuron. 
 * The activitiy of the neuron for the taken action (assuming one action variable) is set to 
 * "MAX_NEURON_ACT". All other neurons have activity "MIN_NEURON_ACT".
 * @author Michel Tokic
 *
 */
public class BinaryActionSetFeatures implements DimensionFeatures {

	private static final long serialVersionUID = 7892467497195410105L;
	protected final ActionSet actionSet;
	protected final double minAction;
	protected final double maxAction;
	
	
	/**
	 * The constructor
	 * @param actionSet The action set
	 */
	public BinaryActionSetFeatures (ActionSet actionSet) {
		this.actionSet = actionSet;
		double minAction = Double.POSITIVE_INFINITY;
		double maxAction = Double.NEGATIVE_INFINITY;
		
		for (int i=0; i<actionSet.size(); i++) {
			double action = actionSet.get(i).get(0);
			
			if (action < minAction) {
				minAction= action;
			}
			if (action > maxAction) {
				maxAction= action;
			}	
		}
		
		this.minAction = minAction;
		this.maxAction = maxAction;
		
		System.out.println ("Constructing BinaryActionSetFeatures with " + this.actionSet.size() + 
							" features. Bounds: [" + minAction+ ", " + maxAction + "]");		
	}
	

	@Override
	public double[] getDimensions() {
		return new double[] {minAction, maxAction};
	}

	@Override
	public double[] getFeatures(double action) {
		
		double features[] = new double[actionSet.size()];
		
		for (int i=0; i< actionSet.size(); i++) {
			if (actionSet.get(i).get(0) == action) {
				features[i] = MAX_NEURON_ACT;
			} else {
				features[i] = MIN_NEURON_ACT;
			}
		}
		
		return features;
	}
	
	/**
	 * debugs for ac
	 * @param action
	 */
	public void debugFeatures (Action action) {
		
		double features[] = getFeatures(action.get(0));
		
		// debug state features
		for (int j=0; j<getNumFeatures(); j++) {
			System.out.println ("  " + j + ": " + features[j]);
		}
	}

	@Override
	public int getNumFeatures() {
		return actionSet.size();
	}
	
	public static void main(String[] args) {
		final Action RIGHT = new Action ( new double[]{-20} ); 
		final Action COAST = new Action ( new double[]{0} ); 
		final Action LEFT = new Action ( new double[]{20} );
		
		ActionSet actionSet = new ActionSet();
		actionSet.add(RIGHT);
		actionSet.add(LEFT);
		actionSet.add(COAST);
		
		BinaryActionSetFeatures features = new BinaryActionSetFeatures (actionSet);
		features.debugFeatures(COAST);
	}
}
