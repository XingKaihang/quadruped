package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.valuefunction;

import java.io.Serializable;

import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner.QLearningBatch;


/**
 * Batch training relevant functions
 * @author tokicm
 *
 */
public interface BatchTraining extends Serializable {

	// Function for training the batch
	public void trainBatch(int epochs);
	
	// Function for adding Q-Values to the batch
	public void putQValues (QLearningBatch qBatch);
}
