package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.util;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NetworkFeatures;
import org.hswgt.teachingbox.core.rl.agent.Agent;
import org.hswgt.teachingbox.core.rl.agent.AgentObserver;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.Environment;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.experiment.Experiment;
import org.hswgt.teachingbox.core.rl.policy.Policy;
import org.hswgt.teachingbox.core.rl.tools.ObjectSerializer;
import org.hswgt.teachingbox.core.rl.valuefunctions.QFunction;


/**
 * This class evaluates a policy after every "N" episodes for "M" randomly drawn start positions.
 * @author tokicm
 *
 */
public class PolicyEvaluator implements AgentObserver, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4619339994423408787L;

	/**
	 * Logger
	 */
    private final static Logger log4j = Logger.getLogger("PolicyEvaluator");

	/**
	 * after testEpisodes the Policy is evaluated  
	 */
	private int testEpisode; 
	
	/**
	 * the amount of random start positions for evaluating the policy
	 */
	private int randStartPositions;
	
	/**
	 * The maximum number of steps
	 */
	private int maxSteps;
	
	/**
	 * the environment object
	 */
	private Environment env;
	
	/**
	 * the policy object
	 */
	private Policy pi;
	
	private State initState = null;
	
	
	/**
	 * the local episode counter
	 */
	protected int iEpisode;
	
	
	/**
	 * Memorizes transition samples for visualization
	 */
	NetworkFeatures features = null;
	TrajectoryPlotter2D transitionVisualizer = null;
	private PolicyEvaluatorDataAverager dataAverager = new PolicyEvaluatorDataAverager();
	
	
	/**
	 * stuff for terminating the experiment
	 */
	public enum STOP_CRITERION {LOWER_OR_EQUAL_THAN, HIGHER_OR_EQUAL_THAN, NONE};
	private STOP_CRITERION stopCriterion = STOP_CRITERION.NONE;
	protected double terminationGoalStateRate = Double.POSITIVE_INFINITY;
	protected String filenameQ = null;
	private QFunction Q = null;
	
	
	
	
	/**
	 * The constructor.
	 * @param features If this variable is != null, all transition samples are visualized using the SOM class (with one cluster)
	 * @param pi The policy to be evaluated
	 * @param env The environment to be evaluated
	 * @param testEpisode After every testEpisodes episodes, the learned Q-function is evaluated 
	 * @param randStartPositions The amount of random start positions to be evaluated 
	 * @param maxSteps The maximum number of steps per episode
	 */
	public PolicyEvaluator (Policy pi, Environment env, int testEpisode, int randStartPositions, int maxSteps) {
		this.pi = pi;
		this.env = env;
		this.testEpisode = testEpisode;
		this.randStartPositions = randStartPositions;
		this.maxSteps = maxSteps;
		this.stopCriterion = STOP_CRITERION.NONE;
	}

	/**
	 * This function evaluates the policy after each learning episode
	 */
	@Override
	public void updateNewEpisode(State arg0) { 
		
		if ((iEpisode%testEpisode)==0 && iEpisode > 0) {
			
			String startString = this.initState == null ? " random " : " fixed ";
			
			// create agent for given policy
			System.out.println  ("EVALUATING Q-FUNCTION IN EPISODE=" + iEpisode + 
					" for " + randStartPositions + startString + " start positions");
			Agent agent = new Agent (pi);
			Experiment experiment = new Experiment (agent, env, randStartPositions, maxSteps);
			
			if (this.initState != null) {
				experiment.setInitState(this.initState);
			}
			experiment.addObserver(dataAverager);

			// optionally visualize transitions in a 2d statespace
			if (transitionVisualizer != null) {
				transitionVisualizer.setPlotTitle("Test trajectories in episode " + (iEpisode+1));
				experiment.addObserver(transitionVisualizer);
				transitionVisualizer.clear();
			}
			
			// run experiment
			experiment.run();
			System.out.println ("TEST RESULTS OF EPISODE " + iEpisode + ":");
			System.out.println ("  - AVERAGE STEPS: " + dataAverager.getAverageEpisodeLength());
			System.out.println ("  - GOAL STATE RATE: " +  dataAverager.getGoalStateRate());
			
			
			/**
			 * CHECK FOR TERMINATION CRITERION
			 */
			if (stopCriterion != STOP_CRITERION.NONE) {
				
				if (stopCriterion == STOP_CRITERION.HIGHER_OR_EQUAL_THAN) {
				
					if (dataAverager.getGoalStateRate() >= terminationGoalStateRate) {
						
						System.out.println ("EXPERIMENT STOPPED BECAUSE TERMINATION CRITERION IS FULLFILLED: " + 
											stopCriterion.name() + " " + terminationGoalStateRate);
												
						if (filenameQ != null) {
							System.out.println ("The Q-function is memorized to: " + filenameQ);
							ObjectSerializer.save(filenameQ, Q);
						}
						
						System.out.println ("FINAL PERFORMANCE OF LEARNING EPISODE '" + iEpisode + "':");
						System.out.println ("  - FINAL AVERAGE STEPS: " + dataAverager.getAverageEpisodeLength());
						System.out.println ("  - FINAL GOAL STATE RATE: " +  dataAverager.getGoalStateRate());
						
						System.exit(0);
					}
				}
				
				if (stopCriterion == STOP_CRITERION.LOWER_OR_EQUAL_THAN) {
					
					if (dataAverager.getGoalStateRate() <= terminationGoalStateRate) {
						
						System.out.println ("EXPERIMENT STOPPED BECAUSE TERMINATION CRITERION IS FULLFILLED: " + 
								stopCriterion.name() + " " + terminationGoalStateRate);

						if (filenameQ != null) {
							System.out.println ("The Q-function is memorized to: " + filenameQ);
							ObjectSerializer.save(filenameQ, Q);
						}
						
						System.out.println ("FINAL PERFORMANCE OF LEARNING EPISODE '" + iEpisode + "':");
						System.out.println ("  - FINAL AVERAGE STEPS: " + dataAverager.getAverageEpisodeLength());
						System.out.println ("  - FINAL GOAL STATE RATE: " +  dataAverager.getGoalStateRate());
						
						System.exit(0);
					}
				}
			}
		}

		this.iEpisode++;
	}
	
	/**
	 * configures an initial state
	 */
	public void setInitState (State state) {
		this.initState = state.copy();
	}
	
	@Override
	public void update(State state, Action action, State arg2, Action arg3,
			double arg4, boolean arg5) {
	}
	
	/**
	 * This function configures termination of the learning process if a desired goal state rate is achieved. 
	 * @param stopCriterion The desired termination criterion
	 * @param terminationGoalStateRate Desired goal state (0 < goalStateRate < 1) rate for terminating the NFQ usecase. 
	 */
	public void terminateOnGoalStateRate (STOP_CRITERION stopCriterion, double terminationGoalStateRate) {
		this.stopCriterion = stopCriterion;
		this.terminationGoalStateRate = terminationGoalStateRate;
	}
	
	/**
	 * This function configures termination of the learning process if a desired goal state rate is achieved. In addition, the Q-function is saved to file. 
	 * @param stopCriterion The desired termination criterion
	 * @param terminationGoalStateRate Desired goal state (0 < goalStateRate < 1) rate for terminating the NFQ usecase. 
	 * @param filname The filename for the Q-function object
	 */
	public void terminateOnGoalStateRate (STOP_CRITERION stopCriterion, double terminationGoalStateRate, QFunction Q, String filename) {
		terminateOnGoalStateRate(stopCriterion, terminationGoalStateRate);
		this.filenameQ = filename;
		this.Q = Q;
		log4j.debug("Q-function will be saved to file: " + filenameQ);
	}
	
	/**
	 * This function enables visualization of a 2D state space
	 * @param features The feature object for the dimensions
	 */
	public void set2dVisualizationFeatures (NetworkFeatures features) {
		this.features = features;
		if (this.features != null) {
			this.transitionVisualizer = new TrajectoryPlotter2D(features);
			log4j.debug ("ADDED NEW TRAJECTORY PLOTTER");
		}
	}
	
}
