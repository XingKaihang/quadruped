package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner;

import java.io.Serializable;
import java.util.LinkedList;
import org.apache.log4j.Logger;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQEnvironment;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQEnvironment.STATE_CLASS;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NetworkFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NFQFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.valuefunction.NFQFunction;
import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.TransitionSampleSARS;
import org.hswgt.teachingbox.core.rl.etrace.ETraceType;
import org.hswgt.teachingbox.core.rl.experiment.ParameterObserver;
import org.hswgt.teachingbox.core.rl.learner.Learner;



/**
 * This is a MLP learner. Transition tuples (s, a, r) are accumulated in a QLearningBatch. 
 * The Q-learning learning rule (without eligibility traces) is performed in each NFQ 
 * iteration on all transition samples for learning the action values.  
 * @author tokicm
 */
public class SingleBatchNFQLearner implements Learner, Serializable, ParameterObserver
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 686393875693434947L;
	protected int iEpisode = 0;
	protected int steps = 0;
	
	protected static final int GOAL_TRAINDATA_PERCENT = 1;
	public static final String PARAM_BATCH_SIZE = "BATCH_SIZE";
	
    // Logger
    private final static Logger log4j = Logger.getLogger("NeuralFittedQLearner");
	
	protected ActionSet actionSet;
	//protected BasicNetwork network;
	protected NFQFunction Q;
	//protected TrainingContinuation trainContinuation = null;


	protected double alpha=0.001;
	protected double gamma=1.0;
	protected int iTerminalState = 0;
	protected int iTransitionSamples = 0;

	protected double R = 0;
	
	
	// episodic etraces
	//protected LinkedList <QLearningBatch> experiences; 
	protected QLearningBatch transitionBatch; 
	protected QLearningBatch goalHeuristicBatch; 
	
	protected int sampleEpisodes; 
	protected int rpropEpochs; 
	protected int nfqIterations;
	protected NFQEnvironment nfqEnv = null;
	protected NFQFeatures features;

	boolean episodicTransitionBatchCleaning = false;
	protected boolean singleBatchMode = false; 
	
	/**
	 * Constructor
	 * 
	 * @param NFQ The neural network Q-function object
	 * @param actionSet The action set
	 * @param features The feature object
	 * @param sampleEpisodes The amount of sample episodes. After every sampleEpisode, the batch of transition samples is trained.
	 * @param nfqIterationsThe amount of NFQ iterations after sampling "sampleEpisodes" episodes
	 * @param rpropEpochs The amount of RPROP epochs for each nfqIteration
	 */
	public SingleBatchNFQLearner(NFQFunction NFQ, NFQEnvironment nfqEnv, NFQFeatures features, int sampleEpisodes, int nfqIterations, int rpropEpochs)
	{
		this.nfqEnv = nfqEnv;
		this.actionSet = nfqEnv.getActionSet();		
		this.Q = NFQ;
		this.features = features;
		
		//this.experiences = new LinkedList <QLearningBatch>();		
		this.goalHeuristicBatch =  new QLearningBatch(NFQ, nfqEnv);
		this.transitionBatch = new QLearningBatch(NFQ, nfqEnv);
		//this.experiences.add(episodicExperience);
		
		this.sampleEpisodes = sampleEpisodes;
		this.nfqIterations = nfqIterations;
		this.rpropEpochs = rpropEpochs;
		

	}
  

	/** 
	 * sets the learning rate alpha
	 * @param alpha
	 */
	public void setAlpha(double alpha)
	{
		this.alpha=alpha;
	}
	
	/**
	 * sets the discounting parameter gamma
	 * @param gamma
	 */
	public void setGamma(double gamma)
	{
		this.gamma=gamma;
	}
		
	/**
	 * add the transition tuple (s,a,s') to the TransitionBatch 
	 */
	@Override
	public void update(State state, Action action, State nextState,
			Action nextAction, double reward, boolean isTerminalState)
	{
		// accumulate reward
        R += reward;
        steps++;
        
        // put transition sample to the batch
       	transitionBatch.putTransitionSample(new TransitionSampleSARS(state, action, nextState, reward));
        
        iTerminalState += isTerminalState == true ? 1 : 0;
        
        // debug transition samples to S^++ states (for allowing to add them to the hint-to-goal heuristics)
        /*
        if (nfqEnv.getStateClass(nextState) == STATE_CLASS.S_PLUSPLUS) {
        	System.out.println ("S_PLUSPLUS:" + "\nS: " + state.toString() + "\nA: " + action.toString() + "\nREWARD: " +  reward + 
        				 "\nS': " + nextState.toString() + "\nA': " + nextAction + "\nTERMINAL: " + isTerminalState);
        }
        */
	}
	
	
	@Override
	public void updateNewEpisode(State initialState)
	{		
		log4j.info("episode " + iEpisode + " ended after " + steps + " transition samples."); 
		log4j.debug ("STARTING STATE: " + initialState.toString());
				
		// train all experiences after every sampleEpisodes
		if((iEpisode%sampleEpisodes) == 0 && iEpisode > 0) {
			
			log4j.info ("starting RPROP training");
			
			for (int i=0; i<nfqIterations; i++) {
			
				// iterate over all episodic experiences
				// do q-learning on all transition samples
				transitionBatch.qLearning(alpha, gamma, 0, ETraceType.none);
				features.setOutputBounds(transitionBatch.getMinQ(), transitionBatch.getMaxQ());
						
				// put q-values to NFQ-function
				Q.putQValues(transitionBatch);
					
				 				
				
				// add goal heuristics 
				int goalHeuristics = (int)((double)transitionBatch.size() * ((double)GOAL_TRAINDATA_PERCENT/100.0)) - 
									goalHeuristicBatch.size();
				features.addGoalHeuristic(goalHeuristicBatch, goalHeuristics);
				goalHeuristicBatch.qLearning(alpha,  gamma, 0, ETraceType.none);
				features.setOutputBounds(goalHeuristicBatch.getMinQ(), goalHeuristicBatch.getMaxQ());
								
				Q.putQValues(goalHeuristicBatch);
				log4j.info(	"Start training of " + transitionBatch.size() + " transition samples " + 
							"(plus " + goalHeuristicBatch.size() + " goal hints)");


				// start training
				log4j.info("NFQ-Iteration: " + i + ", " +
						"transitionBatch.size: " + transitionBatch.size() + ", " +
						"Q-table.size: " + Q.getTrainDataSize() + ", " + 
						"RPROP-Epochs: " + this.rpropEpochs);
				Q.trainBatch(this.rpropEpochs);
				Q.clearQTable();
			}
			
			if (this.episodicTransitionBatchCleaning) {
				this.transitionBatch.clear();
				this.Q.clearQTable();
				this.iTransitionSamples = 0;
			}
		}

		this.iEpisode++;
		
		log4j.debug("Return of last episode: " + R);
		log4j.debug(	"TerminalStates/Episodes: " + iTerminalState + "/" + iEpisode + 
					" = " + ((double)iTerminalState/(double)iEpisode));

		R = 0;		
		steps = 0;
	}
	
	/**
	 * This function sets the option for cleaning the transition batch after each learning episode. (default: false)
	 * @param status
	 */
	public void setEpisodicTransitionBatchCleaning(boolean status) {
		this.episodicTransitionBatchCleaning = status;
	}
	
	/**
	 * sets whether multiple occurences of the same transitions should be allowed or not (default: no)
	 */
	public void setAddRepeatedTransitions (boolean status) {
		transitionBatch.setAddRepeatedTransitions(status);
	}


	@Override
	public double getParameter(State s, Action a, String parameter) {
		if (parameter == PARAM_BATCH_SIZE) {
			return transitionBatch.size();
		} else {
			return -1;
		}
	}	
}
