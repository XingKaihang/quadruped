package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.env;

import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NFQFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NetworkFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NormalizedFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner.QLearningBatch;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.PoleBalanceEnvironment;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.TransitionSampleSARS;


public class PoleBalanceFeatures extends NetworkFeatures implements NFQFeatures {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -703916420429112082L;
		
	public final static double MIN_POS = PoleBalanceEnvironment.MIN_POS;
	public final static double MAX_POS = PoleBalanceEnvironment.MAX_POS;
	public final static double MIN_VEL = PoleBalanceEnvironment.MIN_VEL;
	public final static double MAX_VEL = PoleBalanceEnvironment.MAX_VEL;
	
	public final static double ACTION =  PoleBalanceEnvironment.max_a;
	
	public PoleBalanceFeatures() {
		
		//super(	new double[][]{{MIN_POS, MAX_POS}, {MIN_VEL, MAX_VEL}}, 
		//		new double[]{-ACTION, ACTION});
		this.addStateFeatures(new NormalizedFeatures(MIN_POS, MAX_POS));
		this.addStateFeatures(new NormalizedFeatures(MIN_VEL, MAX_VEL));
		this.addActionFeatures(new NormalizedFeatures(-ACTION, ACTION));
	}
	
	/** 
	 * adds a hint-to-goal heuristic to the QBatch
	 * @return
	 */
	public void addGoalHeuristic(QLearningBatch qbatch, int iSamples) {
		
		
		//double rand;
		
		for (int i=0; i<iSamples; i++) {
			// CENTER
			TransitionSampleSARS sars = new TransitionSampleSARS(
					new State(new double[]{0, 0}),
					new Action(new double[]{ACTION}), 
					new State(new double[]{0, 0}), 0); 
			qbatch.putTransitionSample(sars);
			qbatch.putQValue(sars, 0.0);
	
			sars = new TransitionSampleSARS(
					new State(new double[]{0, 0}),
					new Action(new double[]{ -ACTION}), 
					new State(new double[]{0, 0}), 0);
			qbatch.putTransitionSample(sars);
			qbatch.putQValue(sars, 0.0);
		}
			/*
				
			// LEFT POSITION BOUND
			rand = Uniform.staticNextDoubleFromTo(MIN_VEL, MAX_VEL);
			sars = new TransitionSampleSARS(
					new State(new double[]{MIN_POS, rand}),
					new Action(new double[]{ACTION}), 
					new State(new double[]{MIN_POS, rand}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
			sars = new TransitionSampleSARS(
					new State(new double[]{MIN_POS, rand}),
					new Action(new double[]{-ACTION}), 
					new State(new double[]{MIN_POS, rand}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
			
			// RIGHT POSITION BOUND
			rand = Uniform.staticNextDoubleFromTo(MIN_VEL, MAX_VEL);
			sars = new TransitionSampleSARS(
					new State(new double[]{MAX_POS, rand}),
					new Action(new double[]{ACTION}), 
					new State(new double[]{MAX_POS, rand}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
			sars = new TransitionSampleSARS(
					new State(new double[]{MAX_POS, rand}),
					new Action(new double[]{-ACTION}), 
					new State(new double[]{MAX_POS, rand}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
		
			// UPPER VELOCITY BOUND
			rand = Uniform.staticNextDoubleFromTo(MIN_POS, MAX_POS);
			sars = new TransitionSampleSARS(
					new State(new double[]{rand, MAX_VEL}),
					new Action(new double[]{ACTION}), 
					new State(new double[]{rand, MAX_VEL}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
			
			sars = new TransitionSampleSARS(
					new State(new double[]{rand, MAX_VEL}),
					new Action(new double[]{-ACTION}), 
					new State(new double[]{rand, MAX_VEL}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
			
			// LOWER VELOCITY BOUND
			rand = Uniform.staticNextDoubleFromTo(MIN_POS, MAX_POS);
			sars = new TransitionSampleSARS(
					new State(new double[]{rand, MIN_VEL}),
					new Action(new double[]{ACTION}), 
					new State(new double[]{rand, MIN_VEL}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
			
			sars = new TransitionSampleSARS(
					new State(new double[]{rand, MIN_VEL}),
					new Action(new double[]{-ACTION}), 
					new State(new double[]{rand, MIN_VEL}), -1);			
			qbatch.putQValue(sars, -1);
			qbatch.putTransitionSample(sars);
		}
		*/

	}
	
	
	public static void main(String[] args) {
		
		PoleBalanceFeatures psuf = new PoleBalanceFeatures();
		
		State s  = new State (new double[]{MAX_POS, MIN_VEL});
		Action a = new Action (new double[]{-3});
		psuf.debugFeatures(s, a);
	}
}
