package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env;

import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.PoleBalanceEnvironment;
import org.hswgt.teachingbox.core.rl.env.State;


public class NFQPoleBalanceEnvironment extends PoleBalanceEnvironment implements NFQEnvironment {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6743924075137942021L;

	@Override
	public STATE_CLASS getStateClass(State state) {
		
		// check position
		if (state.get(0) >= MAX_POS || state.get(0) <= MIN_POS || state.get(1) >= MAX_VEL || state.get(1) <= MIN_VEL) {
			return STATE_CLASS.S_MINUS;
			
		} else if (Math.abs(state.get(0)) < 0.1 && Math.abs(state.get(1)) < 0.1) {
			return STATE_CLASS.S_PLUSPLUS;
			
		} else {
			return STATE_CLASS.NORMAL;
		}
	}

	@Override
	public ActionSet getActionSet() {
		// TODO Auto-generated method stub
		return this.ACTION_SET;
	}

	@Override
	public double getTerminalQValue(State state) {
		
		STATE_CLASS sClass = getStateClass(state); 
		if (sClass == STATE_CLASS.S_MINUS) {
			return -1;
			
		} else if (sClass== STATE_CLASS.S_PLUS || sClass == STATE_CLASS.S_PLUSPLUS) {
			return 0;
			
		} else {
			System.out.println ("SETTING TERMINAL VALUE TO INFINITY FOR STATE " + state.toString());
			System.exit (-1);
			return Double.POSITIVE_INFINITY;
		}
	}
	
	@Override
	public PROBLEM_TYPE getNfqProblemType() {
		return PROBLEM_TYPE.CONTINUOUS;
	}
}
