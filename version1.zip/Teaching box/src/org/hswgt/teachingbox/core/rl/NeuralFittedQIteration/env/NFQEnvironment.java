package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env;

import java.io.Serializable;

import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Environment;
import org.hswgt.teachingbox.core.rl.env.State;

/**
 * Add this interface to an environment containing "invalid (S^-) or very good (S^+) states", 
 * that should be handeled separately by the NFQLearner 
 * (such as the set S^- from Riedmiller (2005))    
 * @author tokicm
 *
 */
public interface NFQEnvironment extends Environment, Serializable {
	
	/**
	 * The class of the state 
	 *
	 */
	public static enum STATE_CLASS{NORMAL, S_PLUS, S_PLUSPLUS, S_MINUS}
	
	/**
	 * Returns the class of the given state 
	 * @param s The state
	 * @return The calss
	 */
	public STATE_CLASS getStateClass (State state);
	
	/**
	 * Returns the action set of the environment (required by NFQLearner)
	 * @return returns the ACTION_SET
	 */
	public ActionSet getActionSet();
	
	/**
	 * returns the value of the "ideal" Q-value of the termination state (e.g. zero if GOAL_POS is reached in the mountain-car problem) 
	 * @param state The state to check
	 * @return The ideal termination Q-value 
	 */
	public double getTerminalQValue(State state);
	

	/**
	 * The problem class of the environment
	 */
	public static enum PROBLEM_TYPE {EPISODIC, CONTINUOUS}
	public PROBLEM_TYPE getNfqProblemType();

}

