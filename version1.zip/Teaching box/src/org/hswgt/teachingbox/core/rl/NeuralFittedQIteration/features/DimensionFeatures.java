package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

/**
 * This interfaces provides nessessary methods for create features of state or action dimensions. 
 * @author Michel Tokic
 */
public interface DimensionFeatures extends NeuronFeatures {

	/**
	 * returns an array of input activations for the given (state or action) variable
	 * @param variable
	 * @return
	 */
	public double[] getFeatures(double variable);
	
	/**
	 * returns the amount of features for this dimension
	 * @return
	 */
	public int getNumFeatures();
	
	/**
	 * returns an double array containing the dimension [minValue, maxValue]
	 */
	public double[] getDimensions();
}
