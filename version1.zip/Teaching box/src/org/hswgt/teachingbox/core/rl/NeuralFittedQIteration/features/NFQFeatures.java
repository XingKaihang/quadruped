package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner.QLearningBatch;

/**
 * Add this interface to a class if it returns hint-to-goal heuristics
 * @author Michel Tokic
 *
 */
public interface NFQFeatures extends InputFeatures, OutputFeatures {
	
	/**
	 * This function adds a given amount of hint-to-goal heuristics 
	 * (fixed Q-values for certain state-action pairs) to a Q-learning Batch. 
	 * @param qbatch The QLearningBatch
	 * @param iSamples The amount of goal heuristics
	 */
	public void addGoalHeuristic(QLearningBatch qbatch, int iSamples);
}
