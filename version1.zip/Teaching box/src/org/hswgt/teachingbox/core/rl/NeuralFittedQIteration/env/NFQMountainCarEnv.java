/**
 * 
 * $Id: MountainCarEnv.java 833 2013-03-22 14:42:35Z micheltokic $
 * 
 * @version $Rev: 833 $
 * @author $Author: micheltokic $
 * @date $Date: 2013-03-22 15:42:35 +0100 (Fr, 22 Mrz 2013) $
 * 
 */

package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env;

import org.apache.log4j.Logger;
import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.DynamicalSystem;
import org.hswgt.teachingbox.core.rl.env.State;

import cern.jet.random.Uniform;
/**
 * Implementation of the mountain-car environment. The user can choose 
 * between the dynamics of Riedmiller (2005) or from Sutton&Barto (1998).
 */
public class NFQMountainCarEnv extends DynamicalSystem implements NFQEnvironment {
	
    private static final long serialVersionUID = -5017452612992379453L;

    static Logger log4j = Logger.getLogger("NFQMountainCarEnv");
    
    /**
     * Dynamics are from CLSS (clss.sf.net) or Sutton&Barto (1998)
     */
    public static enum MC_DYNAMICS {RIEDMILLER, SUTTON_BARTO}
    private MC_DYNAMICS mcDynamics = MC_DYNAMICS.RIEDMILLER;


	/**
     * rewards
     */
    private final static double REWARD_TERMINAL_FAILURE = -1;
    private final double REWARD_STEP; 
    private final static double REWARD_GOAL = 0;
    
    
    
    /**
     * The minimum horizontal position.
     */
    private final double MIN_POS;
    
    /**
     * The maximum horizontal position.
     */    
    private final double MAX_POS;
    
    /**
     * The minimum velocity.
     */    
    private final double MIN_VEL;
    
    /**
     * The maximum velocity.
     */
    private final double MAX_VEL;
    
    /**
     * The goal position.
     */    
    private final double GOAL_POS;
    
    /**
     * bound violation stuff
     */
    private boolean bound_violation = false;
    private boolean terminateOnBoundViolation = false;
    
	

    /**
     * full throttle backward 
     */
    private final Action BACKWARD;

    /**
     * coast
     */
    private final Action COAST = new Action(new double[]{0});

    /**
     * full throttle forward 
     */
    private final Action FORWARD;




    /**
     * The set of all possible actions
     */
    private static final ActionSet ACTION_SET = new ActionSet();
    
    private double currentAction = 0;
    
    /**
     * time constant
     */
    private static final double dt = 0.05;
    //private static final int number_of_integration_steps = 10;
    
    //public static State STATE_FORBIDDEN = new State (new double[]{-200, -200});


    
    /*
     * the internal state.
     */
    private State currentState = new State (new double[]{0, 0});
    private double position;
    private double velocity;


    /**
     * Creates an environment with 
     * 
     * @param terminateOnBoundViolation If this variable is true, the episodes terminates of position or velocity bounds are violated.
     * @param stepCosts The costs per step (set from the experiment)
     */
    public NFQMountainCarEnv(MC_DYNAMICS dynamics, boolean terminateOnBoundViolation, double rewardStep) {
    	
    	bound_violation=false;
    	this.terminateOnBoundViolation = terminateOnBoundViolation;
    	REWARD_STEP = rewardStep;
    	mcDynamics = dynamics;
    	
    	if (dynamics == MC_DYNAMICS.RIEDMILLER) {
    		MIN_POS = -1.0;
    		MAX_POS = 0.7;
    		GOAL_POS = 0.7;
    		MIN_VEL = -4;
    		MAX_VEL = 4;
    		BACKWARD = new Action(new double[]{-4});
    		FORWARD = new Action(new double[]{4});
    	} else {
    		MIN_POS = -1.2;
    		MAX_POS = 0.5;
    		GOAL_POS = 0.5;
    		MIN_VEL = -0.07;
    		MAX_VEL = 0.07;
    		BACKWARD = new Action(new double[]{-1});
    		FORWARD = new Action(new double[]{1});
    	}    
    	
        /**
         * initialize the ActionSet
         */
        ACTION_SET.add(BACKWARD);
        //ACTION_SET.add(COAST);
        ACTION_SET.add(FORWARD);
        
    }
    
    /**
     * Creates an environment with default step costs of r=-0.01; 
     * 
     * @param terminateOnBoundViolation If this variable is true, the episodes terminates of position or velocity bounds are violated.
     */
    public NFQMountainCarEnv(MC_DYNAMICS dynamics, boolean terminateOnBoundViolation) {
    	
    	this(dynamics, terminateOnBoundViolation, -0.01);
    }
    
    /**
     * Creates an environment with default step costs of r=-0.01 and dynamics of Sutton&Barto (1998) 
     * 
     * @param terminateOnBoundViolation If this variable is true, the episodes terminates of position or velocity bounds are violated.
     */
    public NFQMountainCarEnv(boolean terminateOnBoundViolation) {
    	
    	this(MC_DYNAMICS.SUTTON_BARTO, terminateOnBoundViolation, -0.01);
    }
    
    /**
     * Creates an environment with default step costs of r=-0.01, dynamics of Sutton&Barto (1998) and no bound termination 
     * 
     * @param terminateOnBoundViolation If this variable is true, the episodes terminates of position or velocity bounds are violated.
     */
    public NFQMountainCarEnv() {
    	
    	this(MC_DYNAMICS.SUTTON_BARTO, false, -0.01);
    }
    
    public void setBoundTermination (boolean terminateOnBoundViolation) {
    	bound_violation=false;
    	this.terminateOnBoundViolation = terminateOnBoundViolation; 
    }
    
    
    /*
     * (non-Javadoc)
     * @see env.Environment#doAction(rl.Action)
     */
    public double doAction(final Action a) {
        
    	currentAction = a.get(0);

        // check range of action
        //currentAction = Math.min(currentAction, FORWARD.get(0));
        //currentAction = Math.max(currentAction, BACKWARD.get(0));
        
       
        //System.out.println ("\ncurrent p="+position + ", v=" + velocity);
    	if (mcDynamics == MC_DYNAMICS.RIEDMILLER) {

	    	//System.out.println ("Riedmiller dynamics...");
    		double[] x = new double[] {position, velocity};
	        updateModel(dt, x, x);
	
	        position  = x[0];
	        velocity = x[1];
	    } else {
	    	
	    	//System.out.println ("Sutton&Barton dynamics...");
           
            velocity = velocity + (0.001 * currentAction) - (0.0025 * Math.cos(3 * position));
            position = position + velocity;
    	}
        //System.out.println ("applying action   " + currentAction + " => \tp="+position + ", v=" + velocity);
    	       
               
        if (position < MIN_POS)
        {
        	position = MIN_POS;
        	velocity = 0;
        	if (terminateOnBoundViolation) {
	        	bound_violation = true;
	        	return REWARD_TERMINAL_FAILURE;
        	}
        }

        if (position >= MAX_POS)
        {
        	position = MAX_POS;        	
        	return REWARD_GOAL;
        }

        if (velocity < MIN_VEL)
        {
        	velocity = MIN_VEL;
        	
        	if (terminateOnBoundViolation) {
	        	bound_violation = true;
	        	return REWARD_TERMINAL_FAILURE;
        	}
        }

        if (velocity > MAX_VEL)
        {
        	velocity = MAX_VEL;
        	if (terminateOnBoundViolation) {
	        	bound_violation = true;
	        	return REWARD_TERMINAL_FAILURE;
        	}
        }
        
        this.currentState.set(0, position);
        this.currentState.set(1, velocity);
        
        
        
        return REWARD_STEP;
    }

    /*
     * (non-Javadoc)
     * @see env.Environment#getState()
     */
    public State getState()
    {
    	currentState.set(0, position);
    	currentState.set(1, velocity);
    	/*
    	if (currentState.equals(this.STATE_FORBIDDEN)) {
    		System.out.println ("ForbiddenState");
    	}
    	*/
        return currentState.copy();
    }

    /*
     * (non-Javadoc)
     * @see org.hswgt.teachingbox.env.Environment#isTerminalState()
     */
    public boolean isTerminalState()
    {
        if (position >= GOAL_POS || bound_violation) {
            //System.out.println ("TerminalState reached");
        	if (bound_violation) {
        		log4j.info("MC BOUND VIOLATION");
        	}
            
            return true;
        }
        /*else if(position<MIN_POS)
        {
        	System.out.println ("Forbidden state entered!");
        	return true;
        }*/
        return false;
    }

    /*
     * (non-Javadoc)
     * @see org.hswgt.teachingbox.env.Environment#initRandom()
     */
    public void initRandom() {
    	
        //System.out.println("TERMINATED e=" + episode++ + ", s_0[" + position + ", " + velocity + "]");            

        position = Uniform.staticNextDoubleFromTo(MIN_POS, MAX_POS);
        //velocity = Uniform.staticNextDoubleFromTo(MIN_VEL, MAX_VEL);
        velocity = 0;
        bound_violation = false;
        
        //System.out.println("e=" + episode++ + ", s_0[" + position + ", " + velocity + "]");
        //velocity = Uniform.staticNextDoubleFromTo(MIN_VEL, MAX_VEL);
    }
    
    /*
     * (non-Javadoc)
     * @see org.hswgt.teachingbox.env.Environment#init(org.hswgt.teachingbox.env.State)
     */
    public void init(final State s) {
        //System.out.println("TERMINATED e=" + episode++ + ", s_0[" + position + ", " + velocity + "]");            

        position = s.get(0);
        velocity = s.get(1);
        bound_violation = false;
        //System.out.println("e=" + episode++ + ", s_0[" + position + ", " + velocity + "]");
    }


	/**
	 * Invalid states (such as the velocity and the left position bound) yield to a fixed Q-value in the learner
	 */
	public boolean isValidState(State s) {
		
		
		boolean status = true;
		
		if (s.get(0) <= MIN_POS) {
			status = false;
		} else if (s.get(1) <= MIN_VEL) {
			status = false;
		} else if (s.get(1) >= MAX_VEL) {
			status = false;
		}

		//System.out.println (s.toString()  + " is " + status);
		return status;
	}


	
	/**
	 * This function implements the system dynamics of the mountaincar environment. 
	 * (Adapted from CLSS source code http://ml.informatik.uni-freiburg.de/research/clsquare )
	 * @param x
	 * @param u
	 * @param dx
	 */
	public void derive (double time, double x[], double dx[])
	{
	  double dH,d2H,epdH2,sin_alpha,cos_alpha,v;
	  final int S = 0;
	  final int SP = 1;
	  final double G = 9.81;
	  final double M = 1.0;
	  // static X_t inv_r;
	  
	  // surface function
	  // H(x) := (xx + x) fuer x <0;   x/sqrt(1+5xx) ansonsten
	  
	  dH = dHds(x[S]); // first derivative of the surface function at position "pos"
	  d2H = d2Hds2(x[S]); // second derivative of the surface function at position "pos"
	  epdH2 = 1.0+dH*dH;
	  
	  sin_alpha = dH/Math.sqrt(epdH2);
	  cos_alpha = 1.0/Math.sqrt(epdH2);
	  
	  // Computation of 1/r:
	  //   1. r is always measured positively, therefore operations with abs.
	  //   2. r can be negative.
	  //
	  // inv_r=Tools::abs(d2H/pow(epdH2,1.5));
	  // inv_r=d2H/pow(epdH2,1.5);
	  
	  v = x[SP]/cos_alpha;


	  // Update internal state
	  dx[S] = x[SP];

	  // Tangential force u[0] 
	  double force = currentAction;

	  //double mass = 1.0;// masses[current_mass];
	  dx[SP] = - (G*sin_alpha*cos_alpha) + (force/M*cos_alpha) -(v*v*dH*d2H/(epdH2*epdH2)) ; 
	}
	
	// computation of the first derivative of the surface function H(s) 
	double dHds(double s) {
		if(s<0.0)
			return 2.0*s+1.0;
		
		return 1.0/(Math.pow(1.0 + 5.0*s*s,1.5));
	}

	// computation of the second derivative of the surface function H(s) 
	double d2Hds2(double s) {
		if(s<0.0)
			return 2.0;
		return -15.0*s/(Math.pow(1.0 + 5.0*s*s,2.5));
	}

	@Override
	public ActionSet getActionSet() {
		return ACTION_SET;
	}
	
    
    /**
	 * @return the dynamics
	 */
	public MC_DYNAMICS getDynamics() {
		return mcDynamics;
	}

	/**
	 * @param dynamics the dynamics to set
	 */
	public void setDynamics(MC_DYNAMICS dynamics) {
		this.mcDynamics = dynamics;
	}

	@Override
	/**
	 * returns the class of given state
	 */
	public STATE_CLASS getStateClass(State state) {

		// check goal position
		if (state.get(0) >= GOAL_POS) {
			return STATE_CLASS.S_PLUS;
			
		// check left position bound
		} else if (state.get(0) <= MIN_POS) {
			if (this.terminateOnBoundViolation) {
				return STATE_CLASS.S_MINUS;
			} else {
				return STATE_CLASS.NORMAL;
			}
			
		// check velocity
		} else if (state.get(1) >= MAX_VEL || state.get(1) <= MIN_VEL) {
			if (this.terminateOnBoundViolation) {
				return STATE_CLASS.S_MINUS;
			} else {
				return STATE_CLASS.NORMAL;
			}
		}
		
		return STATE_CLASS.NORMAL;
	}

	@Override
	public double getTerminalQValue(State state) {
		
		STATE_CLASS stateClass = getStateClass (state);
		
		if (stateClass==STATE_CLASS.S_PLUS) {
			return 0.0;
		} else if (stateClass==STATE_CLASS.S_MINUS) {
			return -1;
		}
		
		return -100;
	}
	
	public double getMinPos() {
		return MIN_POS;
	}
	
	public double getMaxPos() {
		return MAX_POS;
	}
	
	public double getMinVel() {
		return MIN_VEL;
	}
	
	public double getMaxVel() {
		return MAX_VEL;
	}
	
	public double getGoalPos() {
		return GOAL_POS;
	}
	
	public double getMaxAction() {
		return FORWARD.get(0);
	}

	@Override
	public PROBLEM_TYPE getNfqProblemType() {
		return PROBLEM_TYPE.EPISODIC;
	}
}
