package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

import java.io.Serializable;

/**
 * This interfaces contains meta information of a neuron (such as maximum or minimum activation) 
 * @author Michel Tokic
 *
 */
public interface NeuronFeatures extends Serializable {
    

	/**
	 * The minimum activation of a neuron
	 */
	public static final double MIN_NEURON_ACT = 0.05;
	
	/**
	 * The maximum activation of a neuron
	 */
	public static final double MAX_NEURON_ACT = 0.95;
}
