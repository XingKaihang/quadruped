package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

import org.apache.log4j.Logger;
import org.encog.mathutil.BoundNumbers;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;

/**
 * This method scales a given double variable into the interval [MIN_NEURON_ACT, MAX_NEURON_ACT] 
 * @author Michel Tokic
 *
 */
public class NormalizedFeatures implements DimensionFeatures {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4869859734975711982L;
	
	// Logger
    //private final static Logger log4j = Logger.getLogger("ScaledFeature");
    
    protected final double minValue; 
    protected final double maxValue;
    protected NormUtil norm;

    /** 
     * Constructor that configures the normalization object
     * @param minValue
     * @param maxValue
     */
    public NormalizedFeatures (double minValue, double maxValue) {
    	this.minValue = minValue;
    	this.maxValue = maxValue;
    	this.norm = new NormUtil(minValue, maxValue, MIN_NEURON_ACT, MAX_NEURON_ACT);
    }

	@Override
	public double[] getFeatures(double variable) {
		return new double[] {
				Math.min(
						Math.max(this.norm.normalize(BoundNumbers.bound(variable)), MIN_NEURON_ACT),
						MAX_NEURON_ACT
				)
		};
	}

	@Override
	public int getNumFeatures() {
		return 1;
	}
	
	@Override
	public double[] getDimensions() {
		return new double[]{minValue, maxValue};
	}
	
	
	public static void main(String[] args) {
		NormalizedFeatures features = new NormalizedFeatures(-32, 32);
		
		System.out.println ("-64 => " + features.getFeatures(-64)[0]);
		System.out.println ("-32 => " + features.getFeatures(-32)[0]);
		System.out.println ("0 => " + features.getFeatures(0)[0]);
		System.out.println ("32 => " + features.getFeatures(32)[0]);
		System.out.println ("64 => " + features.getFeatures(64)[0]);
	}
}
