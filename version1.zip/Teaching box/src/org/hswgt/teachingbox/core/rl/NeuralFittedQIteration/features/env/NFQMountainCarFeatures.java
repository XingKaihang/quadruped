package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.env;


import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQMountainCarEnv;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.DiscretizedFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NFQFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NetworkFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NormalizedFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner.QLearningBatch;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.TransitionSampleSARS;

import cern.jet.random.Uniform;
/**
 * This is the feature implementation for the mountaincar environment.  
 * @author tokicm
 *
 */
public class NFQMountainCarFeatures extends NetworkFeatures implements NFQFeatures {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4317187970784651469L;
	
	//public final static int POS_DISCS = 20;
	//public final static int VEL_DISCS = 20;
	//public final static int ACTION_DISCS = 3;
	
	private NFQMountainCarEnv env;
	
	
    /**
     * Constructor with option to set binary state encoding
     * @param env
     * @param binaryStateEncoding
     * @param temperatureEncoding
     */
    public NFQMountainCarFeatures(NFQMountainCarEnv env) {
    	

    	// initialize BasicInputOutputFeatures
    	//super(
    	//		new double[][]{{env.getMinPos(), env.getMaxPos()}, {env.getMinVel(), env.getMaxVel()}},
    	//		new double[]{-1, 1}
    	//);
    	this.addStateFeatures(new NormalizedFeatures(env.getMinPos(), env.getMaxPos()));
    	this.addStateFeatures(new NormalizedFeatures(env.getMinVel(), env.getMaxVel()));
    	this.addActionFeatures(new DiscretizedFeatures(-env.getMaxAction(), env.getMaxAction(), 3));
    	
    	this.env = env;
    }
    

	/** 
	 * adds a hint-to-goal heuristic to the QBatch
	 * @return
	 */
	public void addGoalHeuristic(QLearningBatch qbatch, int iSamples) {
		
		double randVelocity;
				
		for (int i=0; i<iSamples; i++) {
			
			// random velocity
			randVelocity = Uniform.staticNextDoubleFromTo(env.getMinVel(), env.getMaxVel());
			
			// add pattern with position=MAX_POS, velocity=random, action=random
			double randAction = Uniform.staticNextIntFromTo(-1, 1)*env.getMaxAction();
			
			TransitionSampleSARS goal = new TransitionSampleSARS(
					new State(new double[]{env.getMaxPos(), randVelocity}),
					new Action(new double[]{ randAction }), 
					new State(new double[]{env.getMaxPos(), randVelocity}),
					0); 
			
			//qbatch.putQValue(goal, 0);
			qbatch.putTransitionSample(goal);
			
			//this.setOutputBounds(0.0);
		}
	}
	
	/**
	 * test main
	 * @param args
	 */
	public static void main(String[] args) {
		
		NFQMountainCarFeatures mcf = new NFQMountainCarFeatures(new NFQMountainCarEnv(NFQMountainCarEnv.MC_DYNAMICS.RIEDMILLER, false));
		//mcf.setStateActionBinaryEncoding(true);
		//mcf.setStateTemperatureEncoding(true);
		
		mcf.debugFeatures(	new State (new double[]{-0.3, 0.02}), 
							new Action (new double[]{2}));
		/*
		mcf.setOutputBounds(-100, 20);
		System.out.println ("-100 => " + mcf.normalizeOutput(-100));
		System.out.println ("20 => " + mcf.normalizeOutput(20));
		System.out.println ("-70 => " + mcf.normalizeOutput(-70));
		*/
		/*
		mcf.debugFeatures(	new State (new double[]{0.5, 0.07}), 
				new Action (new double[]{0}));
		
		mcf.debugFeatures(	new State (new double[]{-1.0, 0.01}), 
				new Action (new double[]{-4}));
		*/
	}
}
