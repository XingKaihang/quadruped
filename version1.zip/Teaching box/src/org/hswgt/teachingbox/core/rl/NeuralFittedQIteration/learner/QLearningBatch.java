package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQEnvironment;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQEnvironment.STATE_CLASS;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQMountainCarEnv;
import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.StateActionPair;
import org.hswgt.teachingbox.core.rl.env.TransitionSampleSARS;
import org.hswgt.teachingbox.core.rl.etrace.ETraceType;
import org.hswgt.teachingbox.core.rl.policy.GreedyPolicy;
import org.hswgt.teachingbox.core.rl.tabular.HashQFunction;
import org.hswgt.teachingbox.core.rl.tabular.TabularQEtrace;
import org.hswgt.teachingbox.core.rl.valuefunctions.QFunction;


/**
 * This class organizes a QFunction-Batch. It also has some meta functions.
 * @author tokicm
 *
 */
public class QLearningBatch {

	//List<ActionValue> qBatch;
	//List<ActionValue> qNormBatch;
	
	protected LinkedHashSet<TransitionSampleSARS> transitionSamples = new LinkedHashSet<TransitionSampleSARS>();
	//protected LinkedHashMap<StateActionPair, Double> qNormMap = new LinkedHashMap<StateActionPair, Double>(16, (float) 0.75, false);
	
	double minQ = Double.POSITIVE_INFINITY;
	double maxQ = Double.NEGATIVE_INFINITY;
	
	// Logger
    private final static Logger log4j = Logger.getLogger("QBatch");

    // etraces 
	protected LinkedHashMap<StateActionPair, Double> Qtable = new LinkedHashMap<StateActionPair, Double>(); 
    protected TabularQEtrace etrace = new TabularQEtrace();
    
    
    QFunction Q; 
    ActionSet as;
    NFQEnvironment nfqEnv = null;
    

	protected boolean addRepeatedTransitions = false;
    
    
    /**
     * The constructor
     * @param Q The Q-Function object
     * @param as The action set
     * @param nfqEnv If Environment is an NFQEnvironment (containing a set S^-) use this constructor, 
     * in order to check for state bound violation
     */
	public QLearningBatch(QFunction Q, NFQEnvironment nfqEnv) {
		
		//this.isNormalized = isNormalized;
		minQ = Double.POSITIVE_INFINITY;
		maxQ = Double.NEGATIVE_INFINITY;
		
		this.Q = Q; 
		this.as = nfqEnv.getActionSet();
		this.nfqEnv = nfqEnv;
		
		//System.out.println ("NFQEnv=" + nfqEnv);
		
	}
	
	/**
	 * performs a q-iteration with eligibility traces on the batch
	 */
	public void qLearning(double alpha, double gamma, double lambda, ETraceType etraceType) {
		
		minQ = Double.POSITIVE_INFINITY;
		maxQ = Double.NEGATIVE_INFINITY;
		
		log4j.debug("performing Q-Learning on " + this.transitionSamples.size() + " transition samples");
		//log4j.info("lambda=" + lambda + ", etracetype=" + etraceType.name());
		etrace.clear();
		Qtable.clear();
		
		TransitionSampleSARS lastTransitionSample = null;
		
		// perform q-learning rule for each transition sample in the current episode
		for( TransitionSampleSARS tSample : transitionSamples) {
			
			State state = tSample.getState();
			State nextState = tSample.getNextState();
			double reward = tSample.getReward();
			Action action = tSample.getAction();
			
			/*
			log4j.info (	"\nTransition: s=" + state.toString() + 
							", a=" + action.toString() +
							", r=" + reward +
							", s_n=" + nextState.toString());
			*/
			
	        // ELIGIBILITY TRACES
	        if( etraceType == ETraceType.replacing || etraceType == ETraceType.none) {
	            etrace.set(state, action, 1);
	        } else if (etraceType == ETraceType.accumulating)  { 
	            etrace.increment(state, action, 1);
	        }
	        
	        // is the action chosen the best action? (Watkins Q(\lambda)
	        boolean bestAction = (Q.getValue(state,action) == Q.getMaxValue(state));
	        
	        
	        double tdError = getTdError(state, action, nextState, reward, gamma);
			
	        
	        
	        //log4j.info("etrace list size: " + etrace.size());
	        // iteratate through all etraces
	        for(Entry<StateActionPair, Double> et : etrace.entrySet())
	        {
	            State sc = et.getKey().getState();            
	            Action ac = et.getKey().getAction();
	            
	            double newQ = 0;
	                       
	            // value update
	            if (etraceType == ETraceType.none) {
	            	
	            	newQ = getQValue(sc, ac) + (alpha*tdError); 
	            	
	            } else { 
		            
	            	newQ = getQValue(sc, ac) + (alpha*tdError*etrace.get(sc, ac));
	         
	            }
	            
	            // check for S_PLUSPLUS
	            if (nfqEnv.getStateClass(sc) == STATE_CLASS.S_PLUSPLUS) {
	            	newQ = nfqEnv.getTerminalQValue(sc);
	            }
				
				Qtable.put(new StateActionPair(sc,ac), newQ);
				
				if (newQ > maxQ) {
					maxQ = newQ;
				}

				if (newQ < minQ) {
					minQ = newQ;
				}
	        }

	        // clear etraces in case "a" was an exploratory action, or if the use of etraces is not desired
	        if( bestAction == false || etraceType == ETraceType.none) {
	            etrace.clear();

	        // decay the etrace 
	        } else {
	            etrace.decay(lambda, gamma);
	        }

	        lastTransitionSample = tSample;
		}
		if (lastTransitionSample != null) { 
			//System.out.println ("Terminated in state " + lastTransitionSample.toString()+ ", length=" + transitionSamples.size());
		}
	}
	
	// returns the Q-Value of given (state, action). Search order: intern Qtable, QFunction object 
	private double getQValue (State state, Action action) {
		
		
		StateActionPair sa = new StateActionPair (state, action);
		double qValue = Double.NaN;
		
		boolean found = false;
		for( Entry<StateActionPair, Double> saq : Qtable.entrySet() ) {
			
			if (saq.getKey().equals(sa)) {
				qValue = saq.getValue();
				found = true;
				break;
			}
		}
		
		if (!found) {
			qValue = Q.getValue(state, action);				
		}
		
		
		return  qValue;
		
		
		//return Q.getValue(state, action);
	}


	
	protected double getTdError(State s, Action a, State sn, double reward, double gamma)
    {
        
		double tdError = Double.NEGATIVE_INFINITY;
        
        /** State class check */
        STATE_CLASS saClass = nfqEnv.getStateClass(sn);
        
        // STATE_CLASS.S_PLUS
        if (saClass == STATE_CLASS.S_PLUS) {
        	tdError = 0 + gamma*nfqEnv.getTerminalQValue(sn);
        	
        // STATE_CLASS.S_MINUS
        } else if (saClass == STATE_CLASS.S_MINUS) {
        	tdError = reward + gamma*nfqEnv.getTerminalQValue(sn);
        	
        // STATE_CLASS.NORMAL
        } else {
    		double q = getQValue(s, a);
    		GreedyPolicy pi = new GreedyPolicy(Q, as);
            double qn = getQValue (sn, pi.getBestAction(sn));

            tdError = reward + (gamma*qn) - q; 
        }
        
        return tdError;
    }

	/**
	 * returns the batch
	 * @return the batch
	 */
	public LinkedHashMap<StateActionPair, Double> getQTable() {
		return this.Qtable;
	}
	
	/**
	 * Adds a transition sample to the batch.  
	 * @param sa the StateActionPair
	 * @param q the new q-value
	 */
	public void putTransitionSample (TransitionSampleSARS sa) {
		
		// if repeated transitions are allowed, just add sa to the set of transition samples
		if (addRepeatedTransitions) {
			this.transitionSamples.add(sa);
			
		// if repeated transitions are not allowed, check if sa already exists in the set of transition samples
		} else {
			if (!transitionSamples.contains(sa)) {
				transitionSamples.add(sa);
				//System.out.println (sa.toString() + " - adding");
			} //else {
			//	System.out.println (sa.toString() + " - already on the stack");
			//}
		}
	}
	
	/**
	 * Adds a transition sample to the batch.  
	 * @param sa the StateActionPair
	 * @param q the new q-value
	 */
	public void putQValue (StateActionPair sa, double qValue) {

		this.Qtable.put(sa, qValue);

	}
	
	/**
	 * clears the q-batch
	 */
	public void clear() {
		
		log4j.debug("CLEARING BATCH....");
		//this.qBatch.clear();
		//this.qNormBatch.clear();
		
		this.transitionSamples.clear();
		this.Qtable.clear();
		
		// keep bounds, because each episode learns in another area of the statespace
		minQ = Double.POSITIVE_INFINITY;
		maxQ = Double.NEGATIVE_INFINITY;
	}
	
	
	/**
	 * returns the minimum q-value in the batch
	 * @return
	 */
	public double getMinQ() {
		return minQ;
	}
	
	/**
	 * returns the maximum q-value in the batch
	 * @return
	 */
	public double getMaxQ() {
		return maxQ;
	}
	
	/** 
	 * returns the current size of the batch
	 * @return
	 */
	public int size() {
		return transitionSamples.size(); //qBatch.size();
	}
	
	/**
	 * returns element i of the batch
	 * @param i the element to return
	 * @return
	public ActionValue get(int i) {
		
		return qBatch.get(i);
	}
	*/
	
	
	public void printBatch() {
		
		// print transition table
		System.out.println("transition table");
		for( TransitionSampleSARS tSample : transitionSamples ) {
			
			System.out.println (tSample.getState() + " : " + 
					tSample.getAction() + ": " + 
					tSample.getNextState());
		}		

		// print Q-table  
		System.out.println("Q-values");
		for( Entry<StateActionPair, Double> e : Qtable.entrySet() ) {
			
			System.out.println (e.getKey().getState() + " : " + 
								e.getKey().getAction() + ": " +  
								e.getValue());
		}		
	}
	
	/**
	 * sets whether multiple occurences of the same transitions should be allowed or not (default: no)
	 */
	public void setAddRepeatedTransitions (boolean status) {
		this.addRepeatedTransitions = status;
	}
	
	
	/**
	 * main function for basic tests
	 * @param args
	 */
	public static void main(String[] args) {
		
		Logger.getRootLogger().setLevel(Level.DEBUG);

		
		// create QBatch
		QLearningBatch qbatch = new QLearningBatch(new HashQFunction(), new NFQMountainCarEnv());
		
		// add two entries to the set
		qbatch.putTransitionSample(new TransitionSampleSARS (new State(new double[]{3,2}), 
											new Action(new double[]{1}), 
											new State(new double[]{3,3}), 1));
		qbatch.putTransitionSample(new TransitionSampleSARS (	new State(new double[]{4,2}), 
											new Action(new double[]{1}), 
											new State(new double[]{4,2}), 1));
		
		qbatch.qLearning(0.1, 0.9, 0.0, ETraceType.none);	
		
		qbatch.putQValue(new StateActionPair(new State(new double[]{8,9}), 
				 new Action(new double[]{7})), 50);


		qbatch.printBatch();
	}
	
	
}
