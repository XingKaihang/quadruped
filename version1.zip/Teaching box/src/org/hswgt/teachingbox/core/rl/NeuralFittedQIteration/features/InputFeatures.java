package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;

/**
 * This is a generic interface for working with neural network input features.
 * @author Michel Tokic
 */
public interface InputFeatures extends NeuronFeatures {
		
	/**
	 * Returns the input features of a given state/action pair 
	 * @param s The state
	 * @param a The action
	 * @return
	 */
	public double[] getInputFeatures(State s, Action a);	
	
	/**
	 * Returns the amount of input features (amount of neurons on the input layer) 
	 * @return The amount of input neurons
	 */
	public int getNumInputFeatures();
	
}
