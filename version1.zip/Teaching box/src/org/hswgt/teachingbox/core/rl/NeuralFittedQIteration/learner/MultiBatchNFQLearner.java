package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner;

import java.io.Serializable;
import java.util.LinkedList;
import org.apache.log4j.Logger;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQEnvironment;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.env.NFQEnvironment.STATE_CLASS;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NetworkFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features.NFQFeatures;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.valuefunction.NFQFunction;
import org.hswgt.teachingbox.core.rl.datastructures.ActionSet;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.TransitionSampleSARS;
import org.hswgt.teachingbox.core.rl.etrace.ETraceType;
import org.hswgt.teachingbox.core.rl.experiment.ParameterObserver;
import org.hswgt.teachingbox.core.rl.learner.Learner;



/**
 * This is a MLP learner. Transition tuples (s, a, r) are accumulated in a single QLearningBatch 
 * for each episode. Q-learning in combination with eligibility traces is used for learning the action values.  
 * @author tokicm
 */
public class MultiBatchNFQLearner implements Learner, Serializable, ParameterObserver
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 999832947289624212L;
	
	protected int iEpisode = 0;
	protected int steps = 0;
	
	protected static final int GOAL_TRAINDATA_PERCENT = 1;
	

	public static final String PARAM_BATCH_SIZE = "BATCH_SIZE";
	
	
    // Logger
    private final static Logger log4j = Logger.getLogger("NeuralFittedQLearner");
	
	protected ActionSet actionSet;
	//protected BasicNetwork network;
	protected NFQFunction Q;
	//protected TrainingContinuation trainContinuation = null;


	protected double alpha=0.001;
	protected double gamma=1.0;
	protected int iTerminalState = 0;
	protected int iTransitionSamples = 0;
	
	protected double lambda = 0.0;
	protected ETraceType etraceType = ETraceType.replacing;
	
	protected double R = 0;
	
	
	// episodic etraces
	protected LinkedList <QLearningBatch> experiences; 
	protected QLearningBatch episodicExperience; 
	protected QLearningBatch goalHeuristicBatch; 
	
	protected int sampleEpisodes; 
	protected int rpropEpochs; 
	protected int nfqIterations;
	protected NFQEnvironment nfqEnv = null;
	protected NFQFeatures features;

	boolean episodicTransitionBatchCleaning = false;

	
	/**
	 * Constructor
	 * 
	 * @param NFQ The neural network Q-function object
	 * @param actionSet The action set
	 * @param features The feature object
	 * @param sampleEpisodes The amount of sample episodes. After every sampleEpisode, the batch of transition samples is trained.
	 * @param nfqIterationsThe amount of NFQ iterations after sampling "sampleEpisodes" episodes
	 * @param rpropEpochs The amount of RPROP epochs for each nfqIteration
	 */
	public MultiBatchNFQLearner(NFQFunction NFQ, NFQEnvironment nfqEnv, NFQFeatures features, int sampleEpisodes, int nfqIterations, int rpropEpochs)
	{
		this.nfqEnv = nfqEnv;
		this.actionSet = nfqEnv.getActionSet();		
		this.Q = NFQ;
		this.features = features;
		
		this.experiences = new LinkedList <QLearningBatch>();		
		this.goalHeuristicBatch =  new QLearningBatch(NFQ, nfqEnv);
		this.episodicExperience = new QLearningBatch(NFQ, nfqEnv);
		this.experiences.add(episodicExperience);
		
		this.sampleEpisodes = sampleEpisodes;
		this.nfqIterations = nfqIterations;
		this.rpropEpochs = rpropEpochs;
		

	}
		
	/**
	 * sets the eligibility traces type	 
	 * @param etraceType
	 */
	public void setETraceType (ETraceType etraceType) {
		this.etraceType = etraceType;
	}
	
	/**
	 * sets the e-trace decaying parameter
	 * @param lambda
	 */
	public void setLambda (double lambda) {
		this.lambda = lambda;
	}
    
	
	/**
	 * sets the learning rate for Q-learning
	 * @param alpha
	 */
	public void setAlpha(double alpha)
	{
		this.alpha=alpha;
	}
	
	/**
	 * sets the discounting parameter for Q-learning
	 * @param gamma
	 */
	public void setGamma(double gamma)
	{
		this.gamma=gamma;
	}
		
	/**
	 * add the transition tuple (s,a,s') to the TransitionBatch 
	 */
	@Override
	public void update(State state, Action action, State nextState,
			Action nextAction, double reward, boolean isTerminalState)
	{
		// accumulate reward
        R += reward;
        
        // put transition sample to the batch
        episodicExperience.putTransitionSample(new TransitionSampleSARS(state, action, nextState, reward));
        
        steps++;
        iTerminalState += isTerminalState == true ? 1 : 0;
        
        
        // debug transition samples to S^++ states (for allowing to add them to the hint-to-goal heuristics)
        /*
        if (nfqEnv.getStateClass(nextState) == STATE_CLASS.S_PLUSPLUS) {
        	System.out.println ("S_PLUSPLUS:" + "\nS: " + state.toString() + "\nA: " + action.toString() + "\nREWARD: " +  reward + 
        				 "\nS': " + nextState.toString() + "\nA': " + nextAction + "\nTERMINAL: " + isTerminalState);
        }
        */
	}
	
	
	@Override
	public void updateNewEpisode(State initialState)
	{		
		log4j.info("episode " + iEpisode + " ended after " + steps + " transition samples."); 
		log4j.debug ("STARTING STATE: " + initialState.toString());
		
		// add experiences of last episode & Goal heuristic
		if (this.episodicExperience != null) {
			
			// put to experience stack
			experiences.add(episodicExperience);
			iTransitionSamples += episodicExperience.size();
			
			log4j.info("adding experience of episode " + iEpisode + " (" + episodicExperience.size() + " samples)");
		}
		
		// create new experience set
		this.episodicExperience = new QLearningBatch(Q, nfqEnv);
		
		
		// train all experiences after every sampleEpisodes
		if((iEpisode%sampleEpisodes) == 0 && iEpisode > 0) {
			
			for (int i=0; i<nfqIterations; i++) {
			
				int iSamples = 0;

				// iterate over all episodic experiences
				for (QLearningBatch experience : experiences) {
					
					// do q-learning on all transition samples
					experience.qLearning(alpha, gamma, lambda, etraceType);
					features.setOutputBounds(experience.getMinQ(), experience.getMaxQ());
						
					// put q-values to NFQ-function
					Q.putQValues(experience);
					
					// increment total size
					iSamples += experience.size(); 
				}
				
				
				// add goal heuristics 
				int goalHeuristics = (int)((double)iSamples * ((double)GOAL_TRAINDATA_PERCENT/100.0)) - 
									goalHeuristicBatch.size();
				features.addGoalHeuristic(goalHeuristicBatch, goalHeuristics);
				goalHeuristicBatch.qLearning(alpha,  gamma, 0, ETraceType.none);
				features.setOutputBounds(goalHeuristicBatch.getMinQ(), goalHeuristicBatch.getMaxQ());
				
				Q.putQValues(goalHeuristicBatch);
				//log4j.info(	"Start training of " + iSamples + " transition samples " + 
				//			"(plus " + goalHeuristicBatch.size() + " goal hints)");


				// start training
				log4j.info("NFQ-Iteration: " + i + ", " +
						"training samples: " + iSamples + ", " +
						"batch samples: " + Q.getTrainDataSize() + ", " + 
						"learning epochs: " + this.rpropEpochs);
				Q.trainBatch(this.rpropEpochs);
				Q.clearQTable();
			}
			
			if (this.episodicTransitionBatchCleaning) {
				//log4j.info("Clearing transition batch and Q-table");
				this.experiences.clear();
				this.episodicExperience.clear();
				this.Q.clearQTable();
				//this.goalHeuristicBatch.clear();
				this.iTransitionSamples = 0;
				//this.iTerminalState
			}
			//experiences.clear();
		}
		
		

		this.iEpisode++;

		
		log4j.debug("Return of last episode: " + R);
		log4j.debug(	"TerminalStates/Episodes: " + iTerminalState + "/" + iEpisode + 
					" = " + ((double)iTerminalState/(double)iEpisode));

		R = 0;		
		steps = 0;
	}
	
	/**
	 * This function sets the option for cleaning the transition batch after each learning episode. (default: false)
	 * @param status
	 */
	public void setEpisodicTransitionBatchCleaning(boolean status) {
		this.episodicTransitionBatchCleaning = status;
	}

	@Override
	public double getParameter(State s, Action a, String parameter) {
		if (parameter == PARAM_BATCH_SIZE) {
			return iTransitionSamples + episodicExperience.size();
		} else {
			return -1;
		}
	}		
}
