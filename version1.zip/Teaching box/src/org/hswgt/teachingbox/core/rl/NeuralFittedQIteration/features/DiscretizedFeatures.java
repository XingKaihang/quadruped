package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;

/**
 * This class discretizes a given state or action variable. The cell containing the state or 
 * action variable is set to MAX_NEURON_ACT, all others are set to MIN_NEURON_ACT.
 * @author Michel Tokic
 */
public class DiscretizedFeatures implements DimensionFeatures {

	private static final long serialVersionUID = -2092476721990396919L;
	
    protected final double minValue; 
    protected final double maxValue;
    protected final int numDiscs;
    protected final double discWidth;
    
    /**
     * Constructor that initializes 
     * @param minValue The minimum value this dimension can have
     * @param maxValue The maximum value this dimension can have
     * @param numDiscs The amount of partitions within [minValue, maxValue]
     */
    public DiscretizedFeatures (double minValue, double maxValue, int numDiscs) {
    	this.minValue = minValue;
    	this.maxValue = maxValue;
    	this.numDiscs = numDiscs;
    	this.discWidth = (maxValue - minValue) / (double)numDiscs;
    	//System.out.println ("discWidth: " + discWidth);
    }

	@Override
	public double[] getFeatures(double variable) {
		
		double features[] = new double[numDiscs];
		for (int j=0; j<numDiscs; j++) {
			features[j] = MIN_NEURON_ACT;
		}

		// determine grid position
		int gridPos = Math.max(Math.min((int)((variable-minValue) / (discWidth)), (numDiscs-1)), 0);
		//System.out.println ("GridPos: " + gridPos);
		features[gridPos] = MAX_NEURON_ACT;
		
		return features;
	}

	@Override
	public int getNumFeatures() {
		return this.numDiscs;
	}

	@Override
	public double[] getDimensions() {
		return new double[]{minValue, maxValue};
	}

	
	/** 
	 * This function debugs the features "variable" to the console
	 * @param variable
	 */
	public void debugFeatures(double variable) {
		double[] features = this.getFeatures(variable);
		System.out.println ("Debugging features for variable '" + variable + 
						 	"' (min=" + minValue + ", max=" + maxValue + ", discs=" + numDiscs + ")");
		for (int i=0; i<this.numDiscs; i++) {
			System.out.println ("Feature " + i + ": " + features[i]);
		}
		System.out.println ();
	}
	
	
	public static void main(String[] args) {
		DiscretizedFeatures df = new DiscretizedFeatures(-1, 1, 5);
		df.debugFeatures(5);
		df.debugFeatures(-1);
		df.debugFeatures(0);
		df.debugFeatures(1);
		df.debugFeatures(5);
	}

}
