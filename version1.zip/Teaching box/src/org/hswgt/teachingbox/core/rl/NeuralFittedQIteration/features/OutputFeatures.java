package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;


/**
 * This is a generic interface for working with the outputs of a neural network.
 * 
 * @author Michel Tokic
 */
public interface OutputFeatures extends NeuronFeatures {
	

	/**
	 * Sets the output bounds 
	 * @param minQValue minimum Q value
	 * @param maxQValue maximum Q value
	 */
	public void setOutputBounds (double minQValue, double maxQValue);
	
	/**
	 * Returns the output bounds
	 * @return The minimum and maximum (denormalized) Q-values
	 */
	public double[] getOutputBounds();
	
	/**
	 * dynamically adjust output bounds (minimum or maximum) based on the given q-value
	 * @param qValue 
	 */
	public void updateOutputBounds (double qValue);
	
	/**
	 * Returns the denormalized output (according to the output bounds) of a given net value
	 * @param qNet The normalized Q-value computed by the nework 
	 * @return The denormalized Q-value according to the output bounds
	 */
	public double denormalizeOutput(double qNet);
	
	/**
	 * Returns the normalized output (according to the output bounds) of a given Q-value
	 * @param q The Q-value
	 * @return The normalized Q-value according to the output bounds
	 */
	public double normalizeOutput(double q);
}
