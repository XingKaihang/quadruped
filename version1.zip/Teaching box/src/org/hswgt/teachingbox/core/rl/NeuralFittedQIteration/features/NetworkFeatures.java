package org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.features;


import java.io.Serializable;
import java.util.LinkedList;


import org.apache.log4j.Logger;
import org.hswgt.teachingbox.core.rl.NeuralFittedQIteration.learner.QLearningBatch;
import org.hswgt.teachingbox.core.rl.env.Action;
import org.hswgt.teachingbox.core.rl.env.State;
import org.hswgt.teachingbox.core.rl.env.StateActionPair;


/**
 * This class organizes the generation of features for the input layer of a multi-layer perceptron.
 * It also organizes the output scaling of the network.   
 * @author tokicm
 *
 */
public class NetworkFeatures implements Serializable, InputFeatures, OutputFeatures { 

	private static final long serialVersionUID = -4895234508641474176L;
	
	private double minQ = -1;
	private double maxQ = 0;
	private boolean forceMinMax = false;
	
	private LinkedList <DimensionFeatures> stateFeatures = new LinkedList<DimensionFeatures>();
	private LinkedList <DimensionFeatures> actionFeatures = new LinkedList<DimensionFeatures>();
	private int numInputFeatures = 0;
	
    // Logger
    private final static Logger log4j = Logger.getLogger("NetworkFeatures");
	
	
	/**
	 * This function forces the Q-Function to be within a certain interval
	 * @param minQ The minimum Q-value
	 * @param maxQ The maximum Q-value
	 */
	public void forceMinMax (double minQ, double maxQ) {
		this.forceMinMax = true;
		this.minQ = minQ;
		this.maxQ = maxQ;
	}
	
	/**
	 * This method adds a new DimensionFeature to the set of state features
	 * @param dimensionFeatures The DimensionFeatures object
	 */
	public void addStateFeatures (DimensionFeatures dimensionFeatures) {
		this.stateFeatures.add(dimensionFeatures);
		this.numInputFeatures += dimensionFeatures.getNumFeatures();
		System.out.println ("numInputFeatuers=" + this.numInputFeatures);
	}

	/**
	 * This method adds a new DimensionFeature to the set of action features
	 * @param dimensionFeatures The DimensionFeatures object
	 */
	public void addActionFeatures (DimensionFeatures dimensionFeatures) {
		this.actionFeatures.add(dimensionFeatures);
		this.numInputFeatures += dimensionFeatures.getNumFeatures();
		System.out.println ("numInputFeatuers=" + this.numInputFeatures);
	}

	@Override
	public void setOutputBounds(double minQ, double maxQ) {
		
		if (!forceMinMax) {
			if (minQ < this.minQ) {
				this.minQ = minQ;
			} else if (maxQ > this.maxQ) {
				this.maxQ = maxQ;
			}
		}
				
		log4j.debug("Q-bounds: " + this.minQ + ", " + this.maxQ);
	}

	@Override
	public void updateOutputBounds(double qValue) {
		
		if (!forceMinMax) {
			if (qValue < this.minQ) {
				this.minQ = qValue;
			} else if (maxQ > this.maxQ) {
				this.maxQ = qValue;
			}
		}
	}
	
	@Override
	public double[] getOutputBounds() {
		return new double[]{minQ, maxQ};
	}

    @Override
    public double denormalizeOutput(double qNet) {

		NormUtil normQ = new NormUtil(minQ, maxQ, MIN_NEURON_ACT, MAX_NEURON_ACT);
		
		return Math.min(Math.max(normQ.denormalize(qNet), minQ), maxQ);
    }
    
    @Override
    public double normalizeOutput(double q) {
    	
    	NormUtil normQ = new NormUtil(minQ, maxQ, MIN_NEURON_ACT, MAX_NEURON_ACT);
		
		return Math.min(Math.max(normQ.normalize(q), MIN_NEURON_ACT), MAX_NEURON_ACT);
    }

	@Override
	public double[] getInputFeatures(State s, Action a) {
		
		// generate features 
		double features[] = new double[this.numInputFeatures];
		int offset = 0;
		
		// add all state features
		for (int i=0; i<stateFeatures.size(); i++) {
			//try {
				double dimensionFeatures[] = stateFeatures.get(i).getFeatures(s.get(i));
				//System.out.println ("processing features of dimension " + i + ", numFeatures=" + stateFeatures.get(i).getNumFeatures());
				for (int j=0; j<stateFeatures.get(i).getNumFeatures(); j++) {
					
					features[offset+j] = dimensionFeatures[j];
				}
				offset += stateFeatures.get(i).getNumFeatures();
				
			/*
			} catch (Exception e) {
				System.out.println ("i=" + i + ", stateFeatures.get(i)=" + stateFeatures.get(i).getClass().getName());
				e.printStackTrace();
			}
			*/

		}
		
		// add all action features
		for (int i=0; i<actionFeatures.size(); i++) {
			double dimensionFeatures[] = actionFeatures.get(i).getFeatures(a.get(i));
			for (int j=0; j<actionFeatures.get(i).getNumFeatures(); j++) {
				features[offset+j] = dimensionFeatures[j];
			}
			offset += actionFeatures.get(i).getNumFeatures();
		}
		
		return features;
	}

	@Override
	public int getNumInputFeatures() {
		return this.numInputFeatures;
	}
	
	/**
	 * This method debugs the features of s and a to the console
	 * @param s
	 * @param a
	 */
	public void debugFeatures(State s, Action a) {
		
		int offset = 0;
		double features[] = this.getInputFeatures(s, a);
		
		for (int i=0; i<stateFeatures.size(); i++) {
			System.out.println ("State dimension " + i + ": ");
			for (int j=0; j<stateFeatures.get(i).getNumFeatures(); j++) {
				System.out.println ("  " + (offset+j) + ": " + features[offset+j]);
			}			
			offset += stateFeatures.get(i).getNumFeatures();
		}
		
		for (int i=0; i<actionFeatures.size(); i++) {
			System.out.println ("Action dimension " + i + ": ");
			for (int j=0; j<actionFeatures.get(i).getNumFeatures(); j++) {
				System.out.println ("  " + (offset+j) + ": " + features[offset+j]);
			}
			offset += actionFeatures.get(i).getNumFeatures();
		}
	}
	
	/**
	 * This function returns the dimensions [minValue, maxValue] of a given state variable id
	 * @param id The state variable id
	 * @return
	 */
	public double[] getStateDimensions(int stateVariableID) {
		return stateFeatures.get(stateVariableID).getDimensions();
	}

	/**
	 * This function returns the dimensions [minValue, maxValue] of a given action variable id
	 * @param id The state variable id
	 * @return
	 */
	public double[] getActionDimensions(int actionVariableID) {
		return actionFeatures.get(actionVariableID).getDimensions();
	}
	
	/**
	 * returns the amount of state dimensions
	 * @return
	 */
	public int getNumStateDimensions() {
		return stateFeatures.size();
	}
	/**
	 * returns the amount of action dimensions
	 * @return
	 */
	public int getNumActionDimensions() {
		return actionFeatures.size();
	}

	
	/**
	 * Main method for testing funtionality
	 * @param args
	 */
	public static void main(String[] args) {
		
		NetworkFeatures nf = new NetworkFeatures();
		
		nf.addStateFeatures(new DiscretizedTemperatureFeatures(-1, 1, 5));
		nf.addStateFeatures(new NormalizedFeatures(-0.07, 0.07));
		nf.addActionFeatures(new NormalizedFeatures(-1, 1));
		
		State s = new State (new double[]{10, -0.03});
		Action a = new Action (new double[]{0.});
		
		nf.debugFeatures(s,a);
	}
}
